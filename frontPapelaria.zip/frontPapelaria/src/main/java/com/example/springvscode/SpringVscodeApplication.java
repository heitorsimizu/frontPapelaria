package com.example.springvscode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringVscodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringVscodeApplication.class, args);
	}

}

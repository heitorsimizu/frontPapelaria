package com.example.springvscode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringVscodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
